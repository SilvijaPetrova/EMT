package mk.ukim.finki.emt.lab.lab.model.enumerations;

public enum Category {
    NOVEL,
    THRILER,
    HISTORY,
    FANTASY,
    BIOGRAPHY,
    CLASSICS,
    DRAMA
}
